#import <Flutter/Flutter.h>

@interface OnAudioQueryPlugin : NSObject<FlutterPlugin>
@end
