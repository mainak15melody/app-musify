/// The default path used to store or cache the 'queried' images/artworks.
const String defaultArtworksPath = '\\on_audio_query\\mediastore\\artworks';

/// The flutter default assets path.
const String defaultAssetsDirectory = 'AssetManifest.json';
