class OnAudioQueryWindows {}
